'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { Facebook, ExternalLink } from 'lucide-react'

export default function FacebookSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-dark to-[#0d1b2a]">
      <motion.div ref={ref} initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : {}} className="max-w-4xl mx-auto text-center">
        <h2 className="font-amiri text-4xl text-gold mb-4">تابعنا على فيسبوك</h2>
        <p className="text-gray-400 mb-8">انضم لمجتمع رواية موري على صفحتنا الرسمية</p>

        <div className="bg-[#1877f2]/5 border border-[#1877f2]/20 rounded-2xl p-8">
          <Facebook className="w-16 h-16 text-[#1877f2] mx-auto mb-4" />
          <h3 className="text-xl font-bold mb-2">صفحة رواية موري الرسمية</h3>
          <p className="text-gray-400 mb-6">تابع آخر أخبار الرواية، مقتبسات حصرية، وإعلانات الجزء الثاني أولاً بأول</p>

          <a href="https://www.facebook.com/share/18KTWQ8kx9/" target="_blank" rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-gradient-to-r from-[#1877f2] to-[#0d5cb6] text-white px-8 py-3 rounded-full font-bold hover:shadow-lg hover:shadow-blue-500/30 transition-all mb-8">
            <ExternalLink size={18} />
            زيارة الصفحة
          </a>

          <div className="rounded-xl overflow-hidden bg-dark/50">
            <iframe
              src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fshare%2F18KTWQ8kx9%2F&tabs=timeline&width=500&height=400&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId"
              width="100%" height="400" style={{ border: 'none' }} scrolling="no" frameBorder="0" allowFullScreen
              allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" className="rounded-xl"
            />
          </div>
        </div>
      </motion.div>
    </section>
  )
}
