'use client'

import { motion } from 'framer-motion'
import { BookOpen, Quote } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'

export default function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 pb-12 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-gold/5 rounded-full blur-3xl animate-float pointer-events-none" />

      <div className="max-w-7xl mx-auto w-full grid lg:grid-cols-2 gap-12 items-center relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="relative flex justify-center order-2 lg:order-1"
        >
          <div className="absolute inset-0 bg-gold/30 blur-[80px] rounded-full animate-pulse-glow" />
          <motion.div
            whileHover={{ rotateY: -10, rotateX: 5 }}
            transition={{ type: 'spring', stiffness: 300 }}
            className="relative w-[300px] h-[450px] sm:w-[400px] sm:h-[600px] cursor-pointer"
            style={{ perspective: 1000 }}
          >
            <Image src="/1000015569.jpg" alt="غلاف رواية موري" fill className="object-cover rounded-lg shadow-2xl shadow-black/80" priority />
          </motion.div>
        </motion.div>

        <motion.div initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="text-center lg:text-right order-1 lg:order-2">
          <motion.span initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }} className="text-gold font-bold tracking-[3px] text-sm mb-4 block">
            رواية جديدة للكاتب محمد طايع
          </motion.span>

          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="font-amiri text-5xl sm:text-7xl font-bold mb-6 text-gradient-gold leading-tight">
            موري
          </motion.h1>

          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }} className="text-xl text-gray-400 mb-6 font-light">
            التوتّرات بين الحب الحقيقي والأزمات النفسية تحت ضغوط الحياة
          </motion.p>

          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }} className="text-lg leading-relaxed mb-8 text-gray-300">
            رحلة استثنائية في عالم الحب والسحر والغموض، حيث تتقاطع الأقدار وتختبر الولاءات. 
            قصة أمير وغزل والجنّي موري الذي غيّر مجرى حياتهم للأبد.
          </motion.p>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }} className="flex flex-wrap gap-4 justify-center lg:justify-start">
            <Link href="#preview" className="inline-flex items-center gap-2 bg-gradient-to-r from-gold to-gold-dark text-dark px-8 py-4 rounded-full font-bold hover:shadow-lg hover:shadow-gold/30 transition-all hover:-translate-y-1">
              <BookOpen size={20} />
              اقرأ الرواية
            </Link>
            <Link href="#quotes" className="inline-flex items-center gap-2 border-2 border-gold text-gold px-8 py-4 rounded-full font-bold hover:bg-gold hover:text-dark transition-all">
              <Quote size={20} />
              مقتبسات من الرواية
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
