'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { Quote } from 'lucide-react'

const quotes = [
  { text: 'الحب والسحر وجهان لعملة واحدة، وهذا ما حدث مع أمير وقع تحت تأثيرهما في الوقت ذاته', source: 'من وصف الرواية' },
  { text: 'إني أشوفلهم شغل هنا، أو أبعتلهم حاجة، وبعدين إنتي ناسية إن بعدين إنتي ناسية', source: 'حوار من الرواية' },
  { text: 'رفض يسافر معايا من الأول أصلاً، وعقدة كان جاهز؟!', source: 'حوار من الرواية' },
  { text: 'ولكن الجميع ليس كأمير يساعده الوجه الآخر للعمله قد يسيطر السحر على الحب', source: 'وصف الأحداث' },
  { text: 'وماذا تريد من كلا الوجهين أن يسطير على الآخر ومن منهم يساعد الآخر', source: 'تأملات الرواية' },
  { text: 'التوترات بين الحب الحقيقي والأزمات النفسية تحت ضغوط الحياة', source: 'الخط الفاصل للرواية' },
]

function QuoteCard({ quote, index }: { quote: typeof quotes[0]; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-50px' })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ y: -5 }}
      className="relative bg-gradient-to-br from-gold/5 to-accent/5 border border-gold/10 rounded-2xl p-8 hover:border-gold/30 transition-all group"
    >
      <Quote className="absolute top-4 right-4 w-12 h-12 text-gold/10 group-hover:text-gold/20 transition-colors" />
      <p className="font-amiri text-xl leading-relaxed text-gray-200 mb-4 relative z-10">{quote.text}</p>
      <span className="text-gold font-semibold text-sm">{quote.source}</span>
    </motion.div>
  )
}

export default function QuotesSection() {
  const headerRef = useRef(null)
  const isHeaderInView = useInView(headerRef, { once: true })

  return (
    <section id="quotes" className="py-24 px-4 sm:px-6 lg:px-8 bg-dark relative">
      <div className="max-w-7xl mx-auto">
        <motion.div ref={headerRef} initial={{ opacity: 0, y: 30 }} animate={isHeaderInView ? { opacity: 1, y: 0 } : {}} className="text-center mb-16">
          <h2 className="font-amiri text-4xl sm:text-5xl text-gold mb-4">مقتبسات من الرواية</h2>
          <p className="text-gray-500 text-lg">كلمات تنبض بالحياة من عالم موري</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quotes.map((quote, index) => (
            <QuoteCard key={index} quote={quote} index={index} />
          ))}
        </div>
      </div>
    </section>
  )
}
