'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import { Clock, Sparkles } from 'lucide-react'

export default function ComingSoonSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  return (
    <section id="coming" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-accent/10 to-gold/5 border-y border-gold/10">
      <motion.div ref={ref} initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : {}} className="max-w-3xl mx-auto text-center">
        <motion.div
          animate={{ boxShadow: ['0 0 20px rgba(212,175,55,0.3)', '0 0 40px rgba(212,175,55,0.6)', '0 0 20px rgba(212,175,55,0.3)'] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="inline-flex items-center gap-2 bg-gradient-to-r from-gold to-gold-dark text-dark px-6 py-2 rounded-full font-bold mb-8"
        >
          <Clock size={18} />
          قريباً
        </motion.div>

        <h2 className="font-amiri text-3xl sm:text-4xl mb-4">الجزء الثاني في مرحلة التجهيز</h2>
        <p className="text-gray-400 text-lg mb-8">
          استعدوا لمتابعة رحلة أمير وغزل وموري في جزء جديد مليء بالمفاجآت والتقلبات.
        </p>

        <div className="w-full h-2 bg-gold/10 rounded-full overflow-hidden mb-4">
          <motion.div initial={{ width: 0 }} animate={isInView ? { width: '65%' } : {}} transition={{ duration: 3, ease: 'easeOut' }}
            className="h-full bg-gradient-to-r from-gold to-gold-dark rounded-full relative">
            <span className="absolute -top-8 left-1/2 -translate-x-1/2 text-gold font-bold text-sm">65%</span>
          </motion.div>
        </div>

        <motion.p initial={{ opacity: 0 }} animate={isInView ? { opacity: 1 } : {}} transition={{ delay: 1 }}
          className="text-gold font-bold mt-8 flex items-center justify-center gap-2">
          <Sparkles size={20} />
          تابعونا للمزيد من التفاصيل قريباً
        </motion.p>
      </motion.div>
    </section>
  )
}
