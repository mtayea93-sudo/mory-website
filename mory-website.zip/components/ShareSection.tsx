'use client'

import { motion, useInView } from 'framer-motion'
import { useRef, useState } from 'react'
import { Facebook, Twitter, Link as LinkIcon, Check, Share2 } from 'lucide-react'

const shareButtons = [
  { name: 'فيسبوك', icon: Facebook, color: 'bg-[#1877f2]', shadow: 'shadow-blue-500/30', action: () => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank', 'width=600,height=400') },
  { name: 'تويتر', icon: Twitter, color: 'bg-[#1da1f2]', shadow: 'shadow-sky-500/30', action: () => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent('اقرأ رواية موري للكاتب محمد طايع')}&url=${encodeURIComponent(window.location.href)}`, '_blank', 'width=600,height=400') },
]

export default function ShareSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })
  const [copied, setCopied] = useState(false)

  const copyLink = async () => {
    await navigator.clipboard.writeText(window.location.href)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <section id="share" className="py-24 px-4 sm:px-6 lg:px-8 bg-dark-deeper text-center">
      <motion.div ref={ref} initial={{ opacity: 0, y: 30 }} animate={isInView ? { opacity: 1, y: 0 } : {}} className="max-w-4xl mx-auto">
        <div className="mb-12">
          <Share2 className="w-12 h-12 text-gold mx-auto mb-4" />
          <h2 className="font-amiri text-4xl text-gold mb-4">شارك الرواية</h2>
          <p className="text-gray-400 text-lg">ساعدنا في نشر رواية موري مع أصدقائك</p>
        </div>

        <div className="flex justify-center gap-4 flex-wrap">
          {shareButtons.map((button, index) => (
            <motion.button key={button.name} initial={{ opacity: 0, scale: 0 }} animate={isInView ? { opacity: 1, scale: 1 } : {}} transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5, scale: 1.1 }} whileTap={{ scale: 0.95 }} onClick={button.action}
              className={`w-16 h-16 rounded-full ${button.color} text-white flex items-center justify-center shadow-lg ${button.shadow} transition-all`} title={button.name}>
              <button.icon size={24} />
            </motion.button>
          ))}

          <motion.button initial={{ opacity: 0, scale: 0 }} animate={isInView ? { opacity: 1, scale: 1 } : {}} transition={{ delay: 0.4 }}
            whileHover={{ y: -5, scale: 1.1 }} whileTap={{ scale: 0.95 }} onClick={copyLink}
            className={`w-16 h-16 rounded-full ${copied ? 'bg-green-500' : 'bg-gold'} text-dark flex items-center justify-center shadow-lg shadow-gold/30 transition-all`} title={copied ? 'تم النسخ!' : 'نسخ الرابط'}>
            {copied ? <Check size={24} /> : <LinkIcon size={24} />}
          </motion.button>
        </div>

        {copied && (
          <motion.p initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="text-green-400 mt-4 font-semibold">
            تم نسخ الرابط بنجاح!
          </motion.p>
        )}
      </motion.div>
    </section>
  )
}
