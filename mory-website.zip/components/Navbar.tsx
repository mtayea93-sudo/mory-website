'use client'

import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Facebook } from 'lucide-react'
import Link from 'next/link'

const navLinks = [
  { href: '#home', label: 'الرئيسية' },
  { href: '#quotes', label: 'مقتبسات' },
  { href: '#preview', label: 'عن الرواية' },
  { href: '#coming', label: 'الجزء الثاني' },
  { href: '#share', label: 'مشاركة' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className={`fixed top-0 w-full z-50 transition-all duration-300 ${
        scrolled ? 'py-2 glass-effect shadow-lg shadow-black/50 border-b border-gold/20' : 'py-4 bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          <Link href="/" className="font-amiri text-2xl font-bold text-gold tracking-wider">موري</Link>

          <ul className="hidden md:flex gap-8 items-center">
            {navLinks.map((link) => (
              <li key={link.href}>
                <Link href={link.href} className="relative text-gray-300 hover:text-gold transition-colors font-semibold group">
                  {link.label}
                  <span className="absolute -bottom-1 right-0 w-0 h-0.5 bg-gold transition-all duration-300 group-hover:w-full" />
                </Link>
              </li>
            ))}
          </ul>

          <a href="https://www.facebook.com/share/18KTWQ8kx9/" target="_blank" rel="noopener noreferrer"
            className="hidden md:flex items-center gap-2 bg-gradient-to-r from-[#1877f2] to-[#0d5cb6] text-white px-5 py-2 rounded-full font-semibold hover:shadow-lg hover:shadow-blue-500/30 transition-all hover:-translate-y-0.5">
            <Facebook size={18} />
            <span>صفحة الفيسبوك</span>
          </a>

          <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden text-gold p-2">
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden glass-effect border-t border-gold/20"
          >
            <div className="px-4 py-6 space-y-4">
              {navLinks.map((link) => (
                <Link key={link.href} href={link.href} onClick={() => setMobileMenuOpen(false)}
                  className="block text-gray-300 hover:text-gold transition-colors font-semibold py-2">
                  {link.label}
                </Link>
              ))}
              <a href="https://www.facebook.com/share/18KTWQ8kx9/" target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 bg-gradient-to-r from-[#1877f2] to-[#0d5cb6] text-white px-5 py-3 rounded-full font-semibold mt-4">
                <Facebook size={18} />
                صفحة الفيسبوك
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  )
}
