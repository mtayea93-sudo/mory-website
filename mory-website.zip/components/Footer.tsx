'use client'

import { motion } from 'framer-motion'
import { Facebook, Twitter, MessageCircle, Heart } from 'lucide-react'
import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-dark-deeper border-t border-gold/10 py-16 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto text-center">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <h3 className="font-amiri text-4xl text-gold mb-4">موري</h3>
          <p className="text-gray-500 mb-8">رواية محمد طايع - رحلة في عالم الحب والسحر والغموض</p>

          <div className="flex justify-center gap-6 mb-8">
            <Link href="https://www.facebook.com/share/18KTWQ8kx9/" target="_blank" className="text-gray-500 hover:text-[#1877f2] transition-colors">
              <Facebook size={24} />
            </Link>
            <button onClick={() => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent('اقرأ رواية موري')}&url=${encodeURIComponent(window.location.href)}`, '_blank')}
              className="text-gray-500 hover:text-[#1da1f2] transition-colors">
              <Twitter size={24} />
            </button>
            <button onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent('اقرأ رواية موري ' + window.location.href)}`, '_blank')}
              className="text-gray-500 hover:text-[#25d366] transition-colors">
              <MessageCircle size={24} />
            </button>
          </div>

          <div className="border-t border-gold/10 pt-8">
            <p className="text-gray-600 text-sm">© 2024 رواية موري - جميع الحقوق محفوظة</p>
            <p className="text-gray-700 text-xs mt-2 flex items-center justify-center gap-1">
              صنع بـ <Heart size={12} className="text-accent" /> لعشاق الأدب العربي
            </p>
          </div>
        </motion.div>
      </div>
    </footer>
  )
}
