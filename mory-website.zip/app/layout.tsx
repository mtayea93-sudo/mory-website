import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'موري - رواية محمد طايع',
  description: 'رواية موري للكاتب محمد طايع - التوتّرات بين الحب الحقيقي والأزمات النفسية تحت ضغوط الحياة',
  keywords: 'موري, رواية, محمد طايع, أدب عربي, رواية غموض, سحر, حب',
  authors: [{ name: 'محمد طايع' }],
  openGraph: {
    title: 'موري - رواية محمد طايع',
    description: 'رحلة في عالم الحب والسحر والغموض',
    type: 'website',
    locale: 'ar_AR',
    images: [{ url: '/1000015569.jpg', width: 1200, height: 630, alt: 'غلاف رواية موري' }],
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <script dangerouslySetInnerHTML={{ __html: `window.fbAsyncInit=function(){FB.init({appId:'YOUR_APP_ID',xfbml:!0,version:'v18.0'})};` }} />
        <script async defer crossOrigin="anonymous" src="https://connect.facebook.net/ar_AR/sdk.js" />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  )
}
