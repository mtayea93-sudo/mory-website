'use client'

import { useEffect } from 'react'
import Navbar from '@/components/Navbar'
import HeroSection from '@/components/HeroSection'
import QuotesSection from '@/components/QuotesSection'
import PreviewSection from '@/components/PreviewSection'
import ComingSoonSection from '@/components/ComingSoonSection'
import ShareSection from '@/components/ShareSection'
import FacebookSection from '@/components/FacebookSection'
import Footer from '@/components/Footer'
import ParticlesBackground from '@/components/ParticlesBackground'

export default function Home() {
  useEffect(() => { console.log('Mory Website Loaded') }, [])

  return (
    <main className="relative min-h-screen bg-dark-deeper overflow-hidden">
      <ParticlesBackground />
      <Navbar />
      <HeroSection />
      <QuotesSection />
      <PreviewSection />
      <ComingSoonSection />
      <ShareSection />
      <FacebookSection />
      <Footer />
    </main>
  )
}
