'use client'

import { motion, useInView } from 'framer-motion'
import { useRef } from 'react'
import Image from 'next/image'
import { Download, User, Hash, Tag, Building2, CheckCircle2 } from 'lucide-react'

const bookDetails = [
  { icon: User, label: 'الكاتب', value: 'محمد طايع' },
  { icon: Hash, label: 'عدد الفصول', value: '14 فصل + خاتمة' },
  { icon: Tag, label: 'النوع الأدبي', value: 'رواية غموض رومانسية' },
  { icon: Building2, label: 'الناشر', value: 'بوكلاود' },
  { icon: CheckCircle2, label: 'الحالة', value: 'متاحة للقراءة' },
]

export default function PreviewSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: '-100px' })

  return (
    <section id="preview" className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-dark to-dark-deeper">
      <div ref={ref} className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
        <motion.div initial={{ opacity: 0, x: -50 }} animate={isInView ? { opacity: 1, x: 0 } : {}} transition={{ duration: 0.8 }} className="relative flex justify-center">
          <motion.div whileHover={{ scale: 1.05, rotate: -2 }} transition={{ type: 'spring', stiffness: 200 }} className="relative w-[300px] h-[450px] sm:w-[350px] sm:h-[525px]">
            <div className="absolute -top-4 -left-4 w-20 h-20 bg-gradient-to-br from-accent to-red-900 rounded-full flex flex-col items-center justify-center text-white font-bold text-xs z-10 shadow-lg animate-bounce-slow">
              <span>جزء</span>
              <span>أول</span>
            </div>
            <Image src="/1000015569.jpg" alt="رواية موري" fill className="object-cover rounded-xl shadow-2xl" />
          </motion.div>
        </motion.div>

        <motion.div initial={{ opacity: 0, x: 50 }} animate={isInView ? { opacity: 1, x: 0 } : {}} transition={{ duration: 0.8, delay: 0.2 }}>
          <h3 className="font-amiri text-4xl text-gold mb-6">عن رواية موري</h3>
          <p className="text-gray-300 leading-relaxed mb-8 text-lg">
            رواية &quot;موري&quot; للكاتب محمد طايع، تدور أحداثها في إطار من الغموض والرومانسية والسحر. 
            تتناول الرواية قصة أمير الشاب الذي يقع تحت تأثير عمل سحري يغيّر مجرى حياته، 
            وعلاقته بغزل التي تواجه تحديات كبيرة. الجنّي موري يدخل حياة أمير ويصبح صديقه الوحيد.
          </p>

          <ul className="space-y-4 mb-8">
            {bookDetails.map((detail, index) => (
              <motion.li key={detail.label} initial={{ opacity: 0, x: 20 }} animate={isInView ? { opacity: 1, x: 0 } : {}} transition={{ delay: 0.4 + index * 0.1 }}
                className="flex justify-between items-center py-3 border-b border-gold/10">
                <span className="flex items-center gap-2 text-gray-400">
                  <detail.icon size={18} className="text-gold/60" />
                  {detail.label}
                </span>
                <span className="text-gold font-semibold">{detail.value}</span>
              </motion.li>
            ))}
          </ul>

          <motion.a href="/مورى.pdf" download whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-gold to-gold-dark text-dark px-8 py-4 rounded-full font-bold hover:shadow-lg hover:shadow-gold/30 transition-all">
            <Download size={20} />
            تحميل الرواية PDF
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}
